﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pos_library.interfaces
{
    interface IMobilePOS
    {
        string DevicePhoneNumber { get; set; }
        
    }
}
